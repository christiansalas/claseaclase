#include <stdio_ext.h>
#include <string.h>
#include <stdlib.h>
#include "utn.h"

/**
    utn_getNombre :
    @param
    @param
    @return
*/
static int isValidNombre(char* pBuffer)
{
    return 1;
}

/**
    utn_getNombre :
    @param
    @param
    @return
*/
static int getString(char* pBuffer, int limite)
{
    return 1;
}


/**
    utn_getNombre :
    @param
    @param
    @return
*/
int utn_getNombre(  float* pFloat, char* msg,
                    char msgErr[], int reintentos)

{
    int retorno=-1;

    return retorno;
}




















