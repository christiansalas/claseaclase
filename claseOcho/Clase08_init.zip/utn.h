#ifndef UTN_H_INCLUDED
#define UTN_H_INCLUDED

static int isValidNombre(char* pBuffer);

static int getString(char* pBuffer, int limite);

int utn_getNombre(  float* pFloat, char* msg,
                    char msgErr[], int reintentos);


#endif // UTN_H_INCLUDED
