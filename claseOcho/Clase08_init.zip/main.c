#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"


#define CANTIDAD_EMPLEADOS 6

int main()
{
    char nombres[15][50];
    int i;

    for(i=0;i < CANTIDAD_EMPLEADOS;i++)
    {

    }

    return 0;
}






